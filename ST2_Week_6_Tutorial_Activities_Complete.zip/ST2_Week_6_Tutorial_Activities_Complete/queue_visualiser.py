import tkinter as tk
from tkinter import messagebox

NODE_WIDTH = 80
NODE_HEIGHT = 40
VERTICAL_GAP = 10
CANVAS_WIDTH = 300
CANVAS_HEIGHT = 500


# --- Singly Linked List classes from Task 2 ---

class Node:
    def __init__(self, data):
        self.data = data
        self.next = None


class SinglyLinkedList:
    def __init__(self):
        self.head = None

    def insert_at_index(self, data, index):
        new_node = Node(data)
        if index == 0:
            new_node.next = self.head
            self.head = new_node
            return True

        current = self.head
        count = 0
        while current and count < index - 1:
            current = current.next
            count += 1

        if current is None:
            return False

        new_node.next = current.next
        current.next = new_node
        return True

    def delete_value(self, value):
        if self.head is None:
            return False

        if self.head.data == value:
            self.head = self.head.next
            return True

        current = self.head
        while current.next:
            if current.next.data == value:
                current.next = current.next.next
                return True
            current = current.next
        return False

    def search(self, value):
        current = self.head
        index = 0
        while current:
            if current.data == value:
                return index
            current = current.next
            index += 1
        return -1

    def to_list(self):
        arr = []
        current = self.head
        while current:
            arr.append(current.data)
            current = current.next
        return arr


# --- Queue built on top of the Singly Linked List ---

class Queue:
    def __init__(self):
        self.linked_list = SinglyLinkedList()
        self.size = 0

    def enqueue(self, data):
        self.linked_list.insert_at_index(data, self.size)
        self.size += 1

    def dequeue(self):
        if self.size == 0:
            return None
        front_value = self.linked_list.head.data
        self.linked_list.delete_value(front_value)
        self.size -= 1
        return front_value

    def peek(self):
        if self.linked_list.head is None:
            return None
        return self.linked_list.head.data

    def is_empty(self):
        return self.size == 0

    def to_list(self):
        return self.linked_list.to_list()


# --- Queue Visualizer (same GUI layout as Stack Visualizer) ---

class QueueVisualizer:
    def __init__(self, root):
        self.root = root
        self.root.title("Queue Visualizer")

        self.queue = Queue()

        self.canvas = tk.Canvas(root, width=CANVAS_WIDTH, height=CANVAS_HEIGHT, bg='white')
        self.canvas.pack(pady=20)

        control_frame = tk.Frame(root)
        control_frame.pack()

        tk.Label(control_frame, text="Push Value:").grid(row=0, column=0)
        self.enqueue_entry = tk.Entry(control_frame, width=10)
        self.enqueue_entry.grid(row=0, column=1)

        enqueue_btn = tk.Button(control_frame, text="Push", command=self.enqueue_value)
        enqueue_btn.grid(row=0, column=2, padx=5)

        dequeue_btn = tk.Button(control_frame, text="Pop", command=self.dequeue_value)
        dequeue_btn.grid(row=1, column=2, pady=5)

        self.status_label = tk.Label(root, text="", fg="blue", font=("Arial", 12))
        self.status_label.pack(pady=5)

        self.draw_queue()

    def draw_node(self, x, y, data):
        self.canvas.create_rectangle(
            x, y, x + NODE_WIDTH, y + NODE_HEIGHT,
            fill="lightblue", outline="black", width=2
        )
        self.canvas.create_text(
            x + NODE_WIDTH / 2, y + NODE_HEIGHT / 2,
            text=str(data), font=("Arial", 16)
        )

    def draw_queue(self):
        self.canvas.delete("all")
        items = self.queue.to_list()
        x = (CANVAS_WIDTH - NODE_WIDTH) // 2
        y = CANVAS_HEIGHT - NODE_HEIGHT - 10

        # Draw nodes bottom to top (front at bottom, rear at top)
        for i, val in enumerate(reversed(items)):
            self.draw_node(x, y, val)
            y -= NODE_HEIGHT + VERTICAL_GAP

        # Draw label for top
        if items:
            self.canvas.create_text(x + NODE_WIDTH + 40, CANVAS_HEIGHT - NODE_HEIGHT - 10, text="Top", font=("Arial", 12), fill="red")

    def enqueue_value(self):
        try:
            val = int(self.enqueue_entry.get())
        except ValueError:
            messagebox.showerror("Invalid Input", "Please enter an integer value to enqueue.")
            return
        self.queue.enqueue(val)
        self.enqueue_entry.delete(0, tk.END)
        self.status_label.config(text=f"Pushed {val} onto queue")
        self.draw_queue()

    def dequeue_value(self):
        if self.queue.is_empty():
            messagebox.showinfo("Empty Queue", "Queue is empty. Cannot dequeue.")
            return
        val = self.queue.dequeue()
        self.status_label.config(text=f"Popped {val} from queue")
        self.draw_queue()


if __name__ == "__main__":
    root = tk.Tk()
    app = QueueVisualizer(root)

    root.mainloop()
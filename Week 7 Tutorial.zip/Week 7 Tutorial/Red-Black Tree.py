import time, random, string
import tkinter as tk
from tkinter import ttk

# ===== BST =====
class Node:
    def __init__(self, name, phone=None):
        self.name, self.phone = name, phone
        self.left = self.right = None

class BST:
    def __init__(self):
        self.root = None

    def insert(self, root, name, phone):
        if root is None: return Node(name, phone)
        if name < root.name:   root.left = self.insert(root.left, name, phone)
        elif name > root.name: root.right = self.insert(root.right, name, phone)
        else: root.phone = phone
        return root

    def search(self, root, name):
        if root is None or root.name == name: return root
        return self.search(root.left, name) if name < root.name else self.search(root.right, name)

    def find_min(self, root):
        while root.left: root = root.left
        return root

    def delete(self, root, name):
        if root is None: return root
        if name < root.name:   root.left = self.delete(root.left, name)
        elif name > root.name: root.right = self.delete(root.right, name)
        else:
            if root.left is None: return root.right
            if root.right is None: return root.left
            t = self.find_min(root.right)
            root.name, root.phone = t.name, t.phone
            root.right = self.delete(root.right, t.name)
        return root

# ===== AVL =====
class AVLNode:
    def __init__(self, name, phone):
        self.name, self.phone = name, phone
        self.left = self.right = None
        self.height = 1

class AVLTree:
    def __init__(self):
        self.root = None

    def _h(self, n): return n.height if n else 0
    def _bal(self, n): return (self._h(n.left) - self._h(n.right)) if n else 0

    def _rr(self, z):
        y = z.left; z.left, y.right = y.right, z
        z.height = 1 + max(self._h(z.left), self._h(z.right))
        y.height = 1 + max(self._h(y.left), self._h(y.right))
        return y

    def _lr(self, z):
        y = z.right; z.right, y.left = y.left, z
        z.height = 1 + max(self._h(z.left), self._h(z.right))
        y.height = 1 + max(self._h(y.left), self._h(y.right))
        return y

    def insert(self, n, name, phone):
        if not n: return AVLNode(name, phone)
        if name < n.name:   n.left = self.insert(n.left, name, phone)
        elif name > n.name: n.right = self.insert(n.right, name, phone)
        else: n.phone = phone; return n
        n.height = 1 + max(self._h(n.left), self._h(n.right))
        b = self._bal(n)
        if b > 1 and name < n.left.name:   return self._rr(n)
        if b < -1 and name > n.right.name: return self._lr(n)
        if b > 1 and name > n.left.name:   n.left = self._lr(n.left); return self._rr(n)
        if b < -1 and name < n.right.name: n.right = self._rr(n.right); return self._lr(n)
        return n

    def _min(self, n):
        while n.left: n = n.left
        return n

    def delete(self, r, name):
        if not r: return r
        if name < r.name:   r.left = self.delete(r.left, name)
        elif name > r.name: r.right = self.delete(r.right, name)
        else:
            if r.left is None: return r.right
            if r.right is None: return r.left
            t = self._min(r.right)
            r.name, r.phone = t.name, t.phone
            r.right = self.delete(r.right, t.name)
        r.height = 1 + max(self._h(r.left), self._h(r.right))
        b = self._bal(r)
        if b > 1 and self._bal(r.left) >= 0:  return self._rr(r)
        if b > 1 and self._bal(r.left) < 0:   r.left = self._lr(r.left); return self._rr(r)
        if b < -1 and self._bal(r.right) <= 0: return self._lr(r)
        if b < -1 and self._bal(r.right) > 0:  r.right = self._rr(r.right); return self._lr(r)
        return r

    def search(self, n, name):
        if n is None or n.name == name: return n
        return self.search(n.left, name) if name < n.name else self.search(n.right, name)

# ===== Red-Black Tree =====
RED, BLACK = True, False

class RBNode:
    def __init__(self, name, phone=None, color=RED):
        self.name, self.phone, self.color = name, phone, color
        self.left = self.right = self.parent = None

class RedBlackTree:
    def __init__(self):
        self.NIL = RBNode(None, None, BLACK)
        self.root = self.NIL

    def _lr(self, x):
        y = x.right; x.right = y.left
        if y.left != self.NIL: y.left.parent = x
        y.parent = x.parent
        if x.parent is None:        self.root = y
        elif x == x.parent.left:    x.parent.left = y
        else:                        x.parent.right = y
        y.left, x.parent = x, y

    def _rr(self, x):
        y = x.left; x.left = y.right
        if y.right != self.NIL: y.right.parent = x
        y.parent = x.parent
        if x.parent is None:         self.root = y
        elif x == x.parent.right:    x.parent.right = y
        else:                         x.parent.left = y
        y.right, x.parent = x, y

    def insert(self, name, phone):
        nd = RBNode(name, phone, RED)
        nd.left = nd.right = self.NIL
        p, c = None, self.root
        while c != self.NIL:
            p = c
            if name < c.name:   c = c.left
            elif name > c.name: c = c.right
            else: c.phone = phone; return
        nd.parent = p
        if p is None:            self.root = nd
        elif name < p.name:      p.left = nd
        else:                    p.right = nd
        if nd.parent is None:    nd.color = BLACK; return
        if nd.parent.parent is None: return
        self._ins_fix(nd)

    def _ins_fix(self, n):
        while n.parent and n.parent.color == RED:
            gp = n.parent.parent
            if n.parent == gp.left:
                u = gp.right
                if u.color == RED:
                    n.parent.color = u.color = BLACK; gp.color = RED; n = gp
                else:
                    if n == n.parent.right: n = n.parent; self._lr(n)
                    n.parent.color = BLACK; gp.color = RED; self._rr(gp)
            else:
                u = gp.left
                if u.color == RED:
                    n.parent.color = u.color = BLACK; gp.color = RED; n = gp
                else:
                    if n == n.parent.left: n = n.parent; self._rr(n)
                    n.parent.color = BLACK; gp.color = RED; self._lr(gp)
        self.root.color = BLACK

    def search(self, name):
        n = self.root
        while n != self.NIL:
            if name == n.name: return n
            n = n.left if name < n.name else n.right
        return None

    def _transplant(self, u, v):
        if u.parent is None:      self.root = v
        elif u == u.parent.left:  u.parent.left = v
        else:                     u.parent.right = v
        v.parent = u.parent

    def _min(self, n):
        while n.left != self.NIL: n = n.left
        return n

    def delete(self, name):
        z = self.root
        while z != self.NIL:
            if name == z.name: break
            z = z.left if name < z.name else z.right
        if z == self.NIL: return
        y, yc = z, z.color
        if z.left == self.NIL:
            x = z.right; self._transplant(z, z.right)
        elif z.right == self.NIL:
            x = z.left; self._transplant(z, z.left)
        else:
            y = self._min(z.right); yc = y.color; x = y.right
            if y.parent == z: x.parent = y
            else: self._transplant(y, y.right); y.right = z.right; y.right.parent = y
            self._transplant(z, y); y.left = z.left; y.left.parent = y; y.color = z.color
        if yc == BLACK: self._del_fix(x)

    def _del_fix(self, x):
        while x != self.root and x.color == BLACK:
            if x == x.parent.left:
                s = x.parent.right
                if s.color == RED:
                    s.color = BLACK; x.parent.color = RED; self._lr(x.parent); s = x.parent.right
                if s.left.color == BLACK and s.right.color == BLACK:
                    s.color = RED; x = x.parent
                else:
                    if s.right.color == BLACK:
                        s.left.color = BLACK; s.color = RED; self._rr(s); s = x.parent.right
                    s.color = x.parent.color; x.parent.color = BLACK
                    s.right.color = BLACK; self._lr(x.parent); x = self.root
            else:
                s = x.parent.left
                if s.color == RED:
                    s.color = BLACK; x.parent.color = RED; self._rr(x.parent); s = x.parent.left
                if s.right.color == BLACK and s.left.color == BLACK:
                    s.color = RED; x = x.parent
                else:
                    if s.left.color == BLACK:
                        s.right.color = BLACK; s.color = RED; self._lr(s); s = x.parent.left
                    s.color = x.parent.color; x.parent.color = BLACK
                    s.left.color = BLACK; self._rr(x.parent); x = self.root
        x.color = BLACK

# ===== Benchmarking =====
def benchmark(n=1000, search_fraction=0.5, delete_count=100):
    names = [''.join(random.choices(string.ascii_lowercase, k=10)) for _ in range(n)]
    phones = [''.join(random.choices(string.digits, k=10)) for _ in range(n)]
    search_names = random.sample(names, int(n * search_fraction)) + ['notfound'] * int(n * (1 - search_fraction))
    delete_names = random.sample(names, min(delete_count, n))

    bst = BST()
    start = time.time()
    for i in range(n): bst.root = bst.insert(bst.root, names[i], phones[i])
    bst_ins = time.time() - start
    start = time.time()
    found_bst = sum(1 for nm in search_names if bst.search(bst.root, nm))
    bst_src = time.time() - start
    start = time.time()
    for nm in delete_names: bst.root = bst.delete(bst.root, nm)
    bst_del = time.time() - start

    avl = AVLTree()
    start = time.time()
    for i in range(n): avl.root = avl.insert(avl.root, names[i], phones[i])
    avl_ins = time.time() - start
    start = time.time()
    found_avl = sum(1 for nm in search_names if avl.search(avl.root, nm))
    avl_src = time.time() - start
    start = time.time()
    for nm in delete_names: avl.root = avl.delete(avl.root, nm)
    avl_del = time.time() - start

    rbt = RedBlackTree()
    start = time.time()
    for i in range(n): rbt.insert(names[i], phones[i])
    rbt_ins = time.time() - start
    start = time.time()
    found_rbt = sum(1 for nm in search_names if rbt.search(nm))
    rbt_src = time.time() - start
    start = time.time()
    for nm in delete_names: rbt.delete(nm)
    rbt_del = time.time() - start

    return {
        'Insertions':      (bst_ins, avl_ins, rbt_ins),
        'Searches':        (bst_src, avl_src, rbt_src),
        'Deletions':       (bst_del, avl_del, rbt_del),
        'Found In Search': (found_bst, found_avl, found_rbt),
    }

# ===== GUI =====
class BenchmarkApp:
    def __init__(self, master):
        self.master = master
        master.title("BST vs AVL vs Red-Black Tree")
        master.geometry("800x500")

        tk.Label(master, text="BST vs AVL vs Red-Black Tree",
                 font=("Helvetica", 15, "bold")).pack(pady=8)

        tk.Button(master, text="Run Benchmark (n=1000)",
                  command=self.run_benchmark, width=24).pack(pady=5)

        self.result_text = tk.Text(master, height=8, width=85, font=("Courier", 10))
        self.result_text.pack(pady=8)

        cols = ("Operation", "BST (s)", "AVL (s)", "RBT (s)")
        self.table = ttk.Treeview(master, columns=cols, show='headings', height=4)
        for c in cols:
            self.table.heading(c, text=c)
            self.table.column(c, width=160, anchor='center')
        self.table.column("Operation", width=120, anchor='w')
        self.table.pack(pady=8)

    def run_benchmark(self):
        self.result_text.delete(1.0, tk.END)
        res = benchmark(n=1000)

        header = f"{'Operation':<14} {'BST (s)':>12} {'AVL (s)':>12} {'RBT (s)':>12}"
        sep = "-" * 56
        lines = [header, sep]
        for op in ('Insertions', 'Searches', 'Deletions'):
            b, a, r = res[op]
            lines.append(f"{op:<14} {b:>12.6f} {a:>12.6f} {r:>12.6f}")
        lines.append(sep)
        fb, fa, fr = res['Found In Search']
        lines.append(f"Found in search:  BST={fb}  AVL={fa}  RBT={fr}  (out of 1000)")
        self.result_text.insert(tk.END, "\n".join(lines))

        for row in self.table.get_children():
            self.table.delete(row)
        for op in ('Insertions', 'Searches', 'Deletions'):
            b, a, r = res[op]
            self.table.insert('', tk.END, values=(op, f"{b:.6f}", f"{a:.6f}", f"{r:.6f}"))

if __name__ == "__main__":
    root = tk.Tk()
    BenchmarkApp(root)
    root.mainloop()